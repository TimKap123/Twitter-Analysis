package edu.cis.pset1_twitteranalysis;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.fragment.app.FragmentTransaction;

import edu.cis.pset1_twitteranalysis.twitter.TwitterController;

public class MainActivity extends AppCompatActivity
{
    TextView resultsView;
    TextView top5WordsView;
    EditText inputView;
    TwitterController myC;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        top5WordsView = (TextView) this.findViewById(R.id.top5WordsView);
        resultsView = (TextView) this.findViewById(R.id.resultsView);
        inputView = (EditText) this.findViewById(R.id.inputView);

        //TODO 1: Tweet something!
        myC = new TwitterController(this);
    }

    public void testingMethod(View mainScreen)
    {
        String inputVal = inputView.getText().toString();

        resultsView.setText(inputVal);
        myC.findUserStats(inputVal);
        top5WordsView.setText(myC.getTop5());
    }

    public void startQuiz(View view) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, new QuizFragment());
        transaction.addToBackStack(null);
        transaction.commit();

        // Hide the original screen
        findViewById(R.id.original_screen).setVisibility(View.GONE);
    }
}