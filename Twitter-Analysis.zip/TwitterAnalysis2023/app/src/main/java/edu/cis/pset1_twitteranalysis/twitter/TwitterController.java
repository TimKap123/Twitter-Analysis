package edu.cis.pset1_twitteranalysis.twitter;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;

import twitter4j.*;
import twitter4j.conf.ConfigurationBuilder;

import java.io.InputStream;
import java.util.*;

public class TwitterController
{
    private Twitter twitter;
    private ArrayList<Status> statuses;
    private ArrayList<String> tokens;
    private HashMap<String, Integer> wordCounts;
    ArrayList<String> commonWords;
    Context context;

    public TwitterController(Context currContext)
    {
        context = currContext;

        ConfigurationBuilder cb = new ConfigurationBuilder();
        cb.setDebugEnabled(true)
                .setOAuthConsumerKey("BiDgxTunoY7GLqS86f62Q6w1K")
                .setOAuthConsumerSecret("HmqXiuTccATao2QebrFgjYln7XN5XzHaIxCPY3tGBvvHQTDxy8")
                .setOAuthAccessToken("1042321525901152256-xbiLUxES1MDY3NLlV1z9etYGHkLSHn")
                .setOAuthAccessTokenSecret("LTNR4Pl3gkONuCaocGMinpB4GVIeoQFD7Es6DcAZQyNnT");
        TwitterFactory tf = new TwitterFactory(cb.build());
        twitter = tf.getInstance();

        statuses = new ArrayList<>();
        tokens = new ArrayList<>();
        wordCounts = new HashMap<>();
        commonWords = new ArrayList<>();
        getCommonWords();
    }

    /**** PART 1 ***/

    //can be used to get common words from the commonWords txt file
    public void getCommonWords()
    {
        try
        {
            AssetManager am = context.getAssets();

            //this file can be found in src/main/assets
            InputStream myFile = am.open("commonWords.txt");
            Scanner sc = new Scanner(myFile);
            while (sc.hasNextLine())
            {
                commonWords.add(sc.nextLine());
            }
        }
        catch (Exception err)
        {
            Log.d("COMMON_WORDS", err.toString());
        }
    }

    public String postTweet(String message)
    {
        String statusTextToReturn = "";
        try
        {
            Status status = twitter.updateStatus(message);
            statusTextToReturn = status.getText();
        } catch (TwitterException e)
        {
            System.out.println(e.getErrorMessage());
        }
        return statusTextToReturn;
    }

    // Example query with paging and file output.
    private void fetchTweets(String handle)
    {
        //Create a twitter paging object that will start at page 1 and hole 200 entries per page.
        Paging page = new Paging(1, 200);

        //Use a for loop to set the pages and get the necessary tweets.
        for (int i = 1; i <= 10; i++)
        {
            page.setPage(i);

            /* Ask for the tweets from twitter and add them all to the statuses ArrayList.
            Because we set the page to receive 200 tweets per page, this should return
            200 tweets every request. */
            try
            {
                statuses.addAll(twitter.getUserTimeline(handle, page));
            }
            catch (Exception err)
            {
                Log.d("fetchTweets", "could not get user timeline");
            }
        }

        //Write to the file a header message. Useful for debugging.
        int numberOfTweetsFound = statuses.size();
        System.out.println("Number of Tweets Found: " + numberOfTweetsFound);

        //Use enhanced for loop to print all the tweets found.
        int count = 1;
        for (Status tweet : statuses)
        {
            System.out.println(count + ". " + tweet.getText());
            count++;
        }
    }


    /**
     * TODO 2: this method splits a whole status into different words.
     * Each word is considered a token.
     * Store each token in the "tokens" arrayList provided.
     * Loop through the "statuses" ArrayList.
     * different
     */
    private void splitIntoWords()
    {
        // clear the tokens ArrayList to prepare for new data
        tokens.clear();

        // loop through all the tweets in the statuses ArrayList
        for (Status tweet : statuses)
        {
            // split the tweet text into individual words or tokens
            String[] words = tweet.getText().split("\\s+");

            // add each word or token to the tokens ArrayList
            tokens.addAll(Arrays.asList(words));
        }
    }


    /**
     * TODO 3: return a word after removing any punctuation and turn to lowercase from it.
     * If the word is "Adam!!", this method should return "adam".
     * We'll need this method later on.
     * If the word is a common word, return null
     */
    @SuppressWarnings("unchecked")
    private String cleanOneWord(String word)
    {
        //remove any leading or trailing punctuation from the word
        //convert the word to lowercase
        word = word.replaceAll("\\p{Punct}", "").toLowerCase();
        return word;
    }


    /**
     * TODO 4: loop through each word, get a clean version of each word
     * and save the list with only clean words.
     * done
     */
    @SuppressWarnings("unchecked")
    private void createListOfCleanWords()
    {
        ArrayList<String> cleanedWords = new ArrayList<>();

        // loop through all the tokens in the tokens ArrayList
        for (String token : tokens)
        {
            // get a clean version of the token
            String cleanToken = cleanOneWord(token);
            // skip the token if it is a common word or an empty string
            if (commonWords.contains(cleanToken) || cleanToken.isEmpty())
            {
                continue;
            }
            // add the clean token to the cleanedWords ArrayList
            cleanedWords.add(cleanToken);
        }
        // update the tokens ArrayList with the cleaned words
        tokens = cleanedWords;
    }

    /**
     * TODO 5: count each clean word using. Use the frequentWords Hashmap.HAHAHA
     */
    @SuppressWarnings("unchecked")
    private void countAllWords()
    {
        for (String word : tokens)
        {
            if (wordCounts.containsKey(word))
            {
                wordCounts.put(word, wordCounts.get(word) + 1);
            }
            else
            {
                wordCounts.put(word, 1);
            }
        }
    }


    //TODO 6: return the most frequent word's string in any appropriate formatHAHAHA
    @SuppressWarnings("unchecked")
    public String getTopWord()
    {
        String topWord = "";
        int frequency = 0;
        for (Map.Entry<String, Integer> entry : wordCounts.entrySet())
        {
            if (entry.getValue() > frequency)
            {
                frequency = entry.getValue();
                topWord = entry.getKey();
            }
        }
        return topWord;
    }


    //TODO 7: return the most frequent word's count as an integer.HAHAHA
    @SuppressWarnings("unchecked")
    public int getTopWordCount()
    {
        int frequency = 0;
        for (Map.Entry<String, Integer> entry : wordCounts.entrySet())
        {
            if (entry.getValue() > frequency)
            {
                frequency = entry.getValue();
            }
        }
        return frequency;
    }

    // Method to output a twitter handle's top 5 words and their count
    public String getTop5()
    {
        String message = "";
        for (int i = 0; i < 5; i++)
        {
            message = message + getTopWord() + ": " + getTopWordCount() + ". \n";
            wordCounts.remove(getTopWord());
        }
        return message;
    }


    /**
     * TODO 8: you put it all together here.
     * Call the functions you finished in TODO's 2-7.
     * They have to be in the correct order for the program to work.
     * Remember to use .clear() method on collections so that
     * consecutive requests don't count words from previous requests.
     * See flowchart for order
     */

    public String findUserStats(String handle)
    {

        return getTop5();
    }
}