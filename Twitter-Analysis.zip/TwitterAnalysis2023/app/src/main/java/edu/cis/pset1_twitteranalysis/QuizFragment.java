package edu.cis.pset1_twitteranalysis;

import androidx.fragment.app.Fragment;

import android.annotation.SuppressLint;
import android.os.Bundle;

import java.util.ArrayList;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.view.View;
import androidx.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.ViewGroup;

public class QuizFragment extends Fragment
{

    private int score = 0;

    @Nullable
    @Override
    public View onCreateView(@androidx.annotation.Nullable LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_quiz, container, false);

        // Initialize variables to store quiz questions and answers
        ArrayList<String> questions = new ArrayList<>();
        ArrayList<String> answers = new ArrayList<>();

        // Add quiz questions and answers to the arrays
        questions.add("What is the main cause of climate change?");
        answers.add("Burning fossil fuels");
        questions.add("What is the biggest contributor to deforestation?");
        answers.add("Livestock farming");
        questions.add("What is the most effective way to reduce your carbon footprint?");
        answers.add("Using public transportation");
        questions.add("How can you reduce your water usage at home?");
        answers.add("Take shorter showers");
        questions.add("What is the primary source of plastic pollution in the ocean?");
        answers.add("Litter from land-based sources");

        // Initialize a TextView to display the quiz question
        TextView questionView = view.findViewById(R.id.question_text);
        // Initialize an EditText to get user's answer
        EditText answerView = view.findViewById(R.id.answer_input);
        // Initialize a TextView to display the result
        TextView resultView = view.findViewById(R.id.result_text);
        // Initialize a Button to move to the next question
        Button nextButton = view.findViewById(R.id.next_question);
        // Initialize a TextView to display the final score
        TextView finalScoreView = view.findViewById(R.id.final_score);

        final int[] index = {0};
        // Set the text of the questionView to the current quiz question
        questionView.setText(questions.get(index[0]));
        nextButton.setOnClickListener(new View.OnClickListener()
        {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v)
            {
                // Get the user's answer from the answerView
                String answer = answerView.getText().toString();

                // Check if the answer is correct
                if (answer.equalsIgnoreCase(answers.get(index[0])))
                {
                    // If the answer is correct
                    score++;
                    resultView.setText("Correct! Your score is now " + score + ".");

                }
                else
                {
                    // If the answer is incorrect
                    resultView.setText("Incorrect. The correct answer was: " + answers.get(index[0]));
                }

                // Increment the index
                index[0]++;

                if (index[0] < questions.size())
                {
                    // If there are still more questions, set the text of the questionView to the next quiz question
                    questionView.setText(questions.get(index[0]));
                    // Clear the answerView
                    answerView.setText("");
                }
                else
                {
                    // If there are no more questions, make the submit button invisible
                    nextButton.setVisibility(View.INVISIBLE);
                    // Display the final score
                    finalScoreView.setText("Quiz complete! Your final score is " + score + "/5.");
                }
            }
        });
        return view;
    }
}